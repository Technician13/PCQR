clear;
clc;

syms  centerPointX centerPointZ theta ovalA ovalB ...
      lineA lineB lineC...
      spatial_0 spatial_1 spatial_2 spatial_3 spatial_4 spatial_5 ...
      spatial_dot_0 spatial_dot_1 spatial_dot_2 spatial_dot_3 spatial_dot_4 spatial_dot_5 ...
      force_0 force_1 force_2 force_3 force_4 force_5 ...
      swing_0 swing_1 swing_2 swing_3 swing_4 swing_5...
      swing_dot_0 swing_dot_1 swing_dot_2 swing_dot_3 swing_dot_4 swing_dot_5;

xx= [ swing_0; swing_1; swing_2; swing_3; swing_4; swing_5;...
      swing_dot_0; swing_dot_1; swing_dot_2; swing_dot_3; swing_dot_4; swing_dot_5];
 
x=swing_0;
z=swing_2;

cst(1,:)=(((x-centerPointX)*cos(theta)+(z-centerPointZ)*sin(theta))*((x-centerPointX)*cos(theta)+(z-centerPointZ)*sin(theta)))/(ovalA*ovalA) +... 
	   (((centerPointX-x)*sin(theta)+(z-centerPointZ)*cos(theta))*((centerPointX-x)*sin(theta)+(z-centerPointZ)*cos(theta)))/(ovalB*ovalB) - 1;

cst(2,:)= lineA*x+lineB*z+lineC;

x=swing_3;
z=swing_5;
cst(3,:)=(((x-centerPointX)*cos(theta)+(z-centerPointZ)*sin(theta))*((x-centerPointX)*cos(theta)+(z-centerPointZ)*sin(theta)))/(ovalA*ovalA) +... 
	   (((centerPointX-x)*sin(theta)+(z-centerPointZ)*cos(theta))*((centerPointX-x)*sin(theta)+(z-centerPointZ)*cos(theta)))/(ovalB*ovalB) - 1;
   
cst(4,:)= lineA*x+lineB*z+lineC;

for cnt=1:4
    for cnt1=1:size(xx)
        j(cnt,cnt1)=diff(cst(cnt,:),xx(cnt1,:));
    end
end
 
for cnt=1:size(xx)
    for cnt2=1:size(xx)
        h1(cnt,cnt2)=diff(j(1,cnt),xx(cnt2,:));
        h2(cnt,cnt2)=diff(j(2,cnt),xx(cnt2,:));
        h3(cnt,cnt2)=diff(j(3,cnt),xx(cnt2,:));
        h4(cnt,cnt2)=diff(j(4,cnt),xx(cnt2,:));
    end
end
   