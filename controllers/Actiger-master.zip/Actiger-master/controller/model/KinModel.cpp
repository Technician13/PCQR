#include "KinModel.hpp"
#include <pseudo_inverse.hpp>
#include <vector>

using namespace RigidBodyDynamics::Math;
using namespace RigidBodyDynamics;
using namespace quadruped;

//extern variables in RobotDefinition.hpp
	const char* link_name[] =
	{
		"body",
		"LF_J","LF_THIGH","LF_CALF","LF_FOOT",
		"LR_J","LR_THIGH","LR_CALF","LR_FOOT",
		"RF_J","RF_THIGH","RF_CALF","RF_FOOT",
		"RR_J","RR_THIGH","RR_CALF","RR_FOOT"
	};


KinModel::KinModel( RigidBodyDynamics::Model* model):
    gravity_(9.81)
{
    model_ = model;
    Ig_ = dynacore::Matrix::Zero(6,6);
    Jg_ = dynacore::Matrix::Zero(6, model_->qdot_size);
}

KinModel::~KinModel(){
}

void KinModel::UpdateKinematics(const dynacore::Vector & q, 
        const dynacore::Vector & qdot){
    _UpdateCentroidFrame(q, qdot);
}
/********mainly reference to "Dynamic behaviors on the NAO robot_dim with closed-loop 
         whole body operational space control" by Donghyun Kim**************************/
void KinModel::_UpdateCentroidFrame(const dynacore::Vector & q,
        const dynacore::Vector & qdot){
    double mass;
    Vector3d zero_vector;
    zero_vector.setZero();

    Vector3d com_pos;
    Vector3d cm;
    Vector3d link_pos;
    Vector3d p_g;

    getCoMPos(com_pos);
    com_pos_ = com_pos;

    dynacore::Matrix Xg_inv = dynacore::Matrix::Zero(6, 6);
    Ig_.setZero();
    dynacore::Matrix Ag = dynacore::Matrix::Zero(6, model_->qdot_size);

    dynacore::Matrix I = dynacore::Matrix::Zero(6, 6);
    dynacore::Matrix Jsp = dynacore::Matrix::Zero(6, model_->qdot_size);

    int start_idx = _find_body_idx(robot_link::body);
    Matrix3d p;
    Matrix3d cmm;
    Matrix3d R;

    for (int i(start_idx); i<model_->mBodies.size(); ++i){
        R = CalcBodyWorldOrientation(*model_, q, i, false);

        link_pos = CalcBodyToBaseCoordinates ( *model_, q, i, zero_vector, false);

        Jsp.setZero();
        CalcBodySpatialJacobian( *model_, q, i, Jsp, false);

        mass = model_->mBodies[i].mMass;
        I.setZero();
        cm = model_->mBodies[i].mCenterOfMass;
        //cout << "m: " << mass << " mass center: " << cm.transpose() << "\n\n";
        cmm <<
            0.0, -cm[2], cm[1],
            cm[2], 0.0, -cm[0],
            -cm[1], cm[0], 0.0;
        I.setZero();
        I.block(0, 0, 3, 3) = model_->mBodies[i].mInertia + mass * cmm * cmm.transpose();
        I.block(0,3, 3,3) = mass * cmm;
        I.block(3,0, 3,3) = -mass * cmm;//cmm.transpose = - cmm
        I.block(3, 3, 3, 3) = mass * dynacore::Matrix::Identity(3,3);

        p_g = R * (link_pos - com_pos);
        p << 0.0, -p_g[2], p_g[1],
            p_g[2], 0.0, -p_g[0],
            -p_g[1], p_g[0], 0.0;

        Xg_inv.block(0,0, 3,3) = R;
        Xg_inv.block(3,3, 3,3) = R;
        Xg_inv.block(3,0, 3,3) = R * p;
        Ig_ = Ig_ + Xg_inv.transpose() * I * Xg_inv;
        Ag = Ag + Xg_inv.transpose() * I * Jsp;
    }
    Jg_ = Ig_.inverse() * Ag;

    centroid_vel_ = Jg_ * qdot;
}

void KinModel::getCoMJacobian(dynacore::Matrix & Jcom) const {
    Vector3d zero_vector = Vector3d::Zero();
    dynacore::Vector q(robot_dim::num_q);

    Jcom = dynacore::Matrix::Zero(3, model_->qdot_size);
    MatrixNd J(3, model_->qdot_size);

    double mass;
    double tot_mass(0.0);
    int start_idx = _find_body_idx(robot_link::body);

    for (int i(start_idx); i< model_->mBodies.size() ; ++i){
        mass = model_->mBodies[i].mMass;
        // CoM Jacobian Update
        J.setZero();
        CalcPointJacobian(*model_, q, i, model_->mBodies[i].mCenterOfMass, J, false);
        Jcom +=  mass * J;
        tot_mass += mass;
    }
    Jcom /= tot_mass;
}

void KinModel::getCoMPos(dynacore::Vect3 & CoM_pos)const {
    Vector3d zero_vector = Vector3d::Zero();
    dynacore::Vector q(robot_dim::num_q);

    CoM_pos.setZero();
    Vector3d link_pos;

    int start_idx = _find_body_idx(robot_link::body);
    double mass;
    double tot_mass(0.0);
    for (int i(start_idx); i< model_->mBodies.size() ; ++i){
        mass = model_->mBodies[i].mMass;

        // CoM position Update
        link_pos = CalcBodyToBaseCoordinates ( *model_, q, i, 
                model_->mBodies[i].mCenterOfMass, false);
        CoM_pos += mass * link_pos;
        tot_mass += mass;
    }
    CoM_pos /= tot_mass;
}

void KinModel::getCoMVel(dynacore::Vect3 & CoM_vel) const {
    dynacore::Vector q, qdot;
    int start_idx = _find_body_idx(robot_link::body);
    CoM_vel.setZero();
    Vector3d link_vel;

    Vector3d zero_vector = Vector3d::Zero();
    double mass;
    double tot_mass(0.0);
    for (int i(start_idx); i< model_->mBodies.size() ; ++i){
        mass = model_->mBodies[i].mMass;

        // CoM velocity Update
        link_vel = CalcPointVelocity ( *model_, q, qdot, i, model_->mBodies[i].mCenterOfMass, false);
        CoM_vel += mass * link_vel;
        tot_mass += mass;
    }
    CoM_vel /= tot_mass;
}

void KinModel::getPos(int link_id, dynacore::Vect3 & pos){
    Vector3d zero;
    Matrix3d R;
    dynacore::Vector q(robot_dim::num_q);

    int bodyid = _find_body_idx(link_id);
    if(bodyid >=model_->fixed_body_discriminator){
        zero = model_->mFixedBodies[bodyid - model_->fixed_body_discriminator].mCenterOfMass;
    }
    else{
        zero =  model_->mBodies[bodyid].mCenterOfMass;
    }

    pos = CalcBodyToBaseCoordinates(*model_, q, _find_body_idx(link_id), zero, false);
    // R = CalcBodyWorldOrientation( *model_, q, _find_body_idx(link_id), false);
    // pos = R * pos;

}

void KinModel::getOri(int link_id, dynacore::Vect3 & rpy){
    Matrix3d R;
    dynacore::Quaternion ori;
    dynacore::Vector q(robot_dim::num_q);
    R = CalcBodyWorldOrientation( *model_, q, _find_body_idx(link_id), false);
    ori = R.transpose();

    if(ori.w() < 0.){
        ori.w() *= (-1.);
        ori.x() *= (-1.);
        ori.y() *= (-1.);
        ori.z() *= (-1.);
    }
    dynacore::convert(ori, rpy[2], rpy[1], rpy[0]);
}

void KinModel::getLinearVel(int link_id, dynacore::Vect3 & vel){
    Vector3d zero;
    dynacore::Vector q, qdot;

    int bodyid = _find_body_idx(link_id);
    if(bodyid >=model_->fixed_body_discriminator){
        zero = model_->mFixedBodies[bodyid - model_->fixed_body_discriminator].mCenterOfMass;
    }
    else{
        zero =  model_->mBodies[bodyid].mCenterOfMass;
    }

    vel = CalcPointVelocity ( *model_, q, qdot, _find_body_idx(link_id), zero, false);
}

void KinModel::getAngularVel(int link_id, dynacore::Vect3 & ang_vel){
    unsigned int bodyid = _find_body_idx(link_id);
    dynacore::Vector vel, q, qdot;

    if(bodyid >=model_->fixed_body_discriminator){
        vel = CalcPointVelocity6D(*model_, q, qdot, bodyid,
                model_->mFixedBodies[bodyid - model_->fixed_body_discriminator].mCenterOfMass, false);
    }
    else{
        vel = CalcPointVelocity6D(*model_, q, qdot, bodyid,
                model_->mBodies[bodyid].mCenterOfMass, false);
    }
    ang_vel = vel.head(3);
}

void KinModel::getJacobian(int link_id, dynacore::Matrix &J){
    dynacore::Vector q(robot_dim::num_q);
    J = dynacore::Matrix::Zero(6, model_->qdot_size);

    unsigned int bodyid = _find_body_idx(link_id);
    Vector3d zero_vector = Vector3d::Zero();
    
    if(bodyid >=model_->fixed_body_discriminator){
        CalcPointJacobian6D(*model_, q, bodyid,
                model_->mFixedBodies
                [bodyid - model_->fixed_body_discriminator].mCenterOfMass,
                J, false);
    }
    else{
        CalcPointJacobian6D(*model_, q, bodyid,
                model_->mBodies[bodyid].mCenterOfMass,
                J, false);
    }
    /*************this will transform the jacobian from world frame to body frame********/

    // Eigen::Matrix<double, 6, 6> World2Body6D;
    // Eigen::Matrix3d World2Body;
    // World2Body6D.setZero(); World2Body.setZero();
    // World2Body = CalcBodyWorldOrientation( *model_, q, _find_body_idx(link_id), false);
    // World2Body6D.block(0,0,3,3) = World2Body;
    // World2Body6D.block(3,3,3,3) = World2Body;
    
    // J = World2Body6D * J;
}

void KinModel::getJDotQdot(int link_id, dynacore::Vector & JDotQdot){
    dynacore::Vector q, qdot, qddot;

    unsigned int bodyid = _find_body_idx(link_id);
    if(bodyid >=model_->fixed_body_discriminator){
        JDotQdot = CalcPointAcceleration6D(*model_, q, qdot, qddot, bodyid,
                model_->mFixedBodies
                [bodyid - model_->fixed_body_discriminator].mCenterOfMass, false);
    }
    else{
        JDotQdot = CalcPointAcceleration6D(*model_, q, qdot, qddot, bodyid,
                model_->mBodies[bodyid].mCenterOfMass, false);
    }
    JDotQdot[5] -= gravity_;
}

void KinModel::getWorldToBodyMatrix(dynacore::Mat3 & BodyMatrix){
    dynacore::Vector q;
    int body_idx = _find_body_idx(robot_link::body);

    BodyMatrix = CalcBodyWorldOrientation(*model_, q, body_idx, false);
}

unsigned int KinModel::_find_body_idx(int id) const {
    switch(id){
        case robot_link::body:
            return model_->GetBodyId("body");
        case robot_link::LF_foot:
            return model_->GetBodyId("LF_FOOT");
        case robot_link::LR_foot:
            return model_->GetBodyId("LR_FOOT");
        case robot_link::RF_foot:
            return model_->GetBodyId("RF_FOOT");
        case robot_link::RR_foot:
            return model_->GetBodyId("RR_FOOT");
        default:
            std::cout << "unkonown id" << std::endl;
    }
    return 0;
}
unsigned int KinModel::find_body_id(const char* link_name) const{
    unsigned int body_id;
    body_id = model_->GetBodyId(link_name);

    return body_id;
}
//according to this function, to know the number of each joint
void KinModel::displaylinks() {
    int linklist_len;
    linklist_len = sizeof(link_name)/sizeof(link_name[0]);
    cout << "link_num: " << linklist_len << endl;
    vector<const char*> link_name_list(link_name, link_name + linklist_len);
    vector<int> body_id_list;
    int body_id;
    for (int i(0); i < link_name_list.size(); ++i) {
        body_id = model_->GetBodyId(link_name_list[i]);
        body_id_list.push_back(body_id);
    }
    for (int i(0); i < body_id_list.size(); ++i) {
        cout << link_name_list[i] << ": " << body_id_list[i] << endl;
    }

    
}
